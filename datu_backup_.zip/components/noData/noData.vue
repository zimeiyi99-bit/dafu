<template>
	<view>
		<view class="flex flex-column" style="margin-top: 248rpx;">
			<slot></slot>
		</view>
	</view>
</template>

<script>
	export default {
		name: "noData",
		data() {
			return {

			};
		}
	}
</script>

<style lang="less">

</style>