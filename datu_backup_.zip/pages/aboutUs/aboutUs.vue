<template>
	<view class="">
		<guo-headerTitle title="余额宝规则"></guo-headerTitle>
		<view class="rule text-des-color text-md text-align-justify tui-header" style="margin-top: 16px;">
			<p><span style="text-wrap: nowrap;">欢迎使用余额宝，您的智慧财富管理工具。</span></p>
			<p><br></p>
			<p><span style="text-wrap: nowrap;">日化1%</span></p>
			<p><span style="text-wrap: nowrap;">1天后随取随用。</span></p>
			<p><span style="text-wrap: nowrap;">单日转入、转出最高60次。</span></p>
			<p><span style="text-wrap: nowrap;">门槛单笔最低20元，轻松起步，随时加入。</span></p>
			<p><span style="text-wrap: nowrap;">转入余额宝的资金在第二个交易日由基金公司进行份额确认，对已确认的份额，基金公司产生的当天收益会在次日上午08:
					00在余额宝中显示。</span></p>
			<p><span style="text-wrap: nowrap;">温馨提示：08: 00后转入的资金会顺延1个交易日确认，双休日及国家法定假期，基金公司不进行份额确认。</span></p>
			<p><br></p>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="less">
	.tui-header {
		padding: 0 30rpx;
	}

	.text-des-color {
		font-size: 14px;
		color: #a8a9ac;
		line-height: 24px;
		text-align: justify;
	}
</style>