<template>
	<view class="">
		<guo-headerTitle title="关于我们"></guo-headerTitle>
		<view class="text-des-color text-md text-align-justify tui-header" style="line-height: 24px;">
			<p
				style="padding: 0px; margin-top: 0px; margin-bottom: 0px; text-align: justify; color: rgb(102, 102, 102); font-family: ">
				广州期货交易所(以下简称广期所)于2021年4月19日挂牌成立，是经国务院同意，由中国证监会批准设立的第五家期货交易所。广期所由上海期货交易所、郑州商品交易所、大连商品交易所、中国金融期货交易所股份有限公司、中国平安保险(集团)股份有限公司、广州金融控股集团有限公司、广东珠江投资控股集团有限公司、香港交易及结算所有限公司共同发起设立，是国内首家混合所有制交易所。设立广期所，是健全多层次资本市场体系，服务绿色发展，服务粤港澳大湾区建设，服务“一带一路”倡议的重要举措。
			</p>
			<p
				style="padding: 0px; margin-top: 0px; margin-bottom: 0px; text-align: justify; color: rgb(102, 102, 102); font-family: ">
				    2021年5月，广期所两年期品种计划获中国证监会批准，明确将16个期货品种交由广期所研发上市，包括碳排放权、电力等事关国民经济基础领域和能源价格改革的重大战略品种，中证商品指数、能源化工、饲料养殖、钢厂利润等商品指数类创新型品种，工业硅、多晶硅、锂、稀土、铂、钯等与绿色低碳发展密切相关的产业特色品种，咖啡、高粱、籼米等具有粤港澳大湾区与“一带一路”特点的区域特色品种，以及国际市场产品互挂类品种。未来，广期所将不断丰富产品体系，强化市场服务能力，更好满足实体经济风险管理需要。
			</p>
			<p
				style="padding: 0px; margin-top: 0px; margin-bottom: 0px; text-align: justify; color: rgb(102, 102, 102); font-family: ">
				    广期所将以习近平新时代中国特色社会主义思想为指导，坚决贯彻落实党中央、国务院重大决策部署和证监会工作要求，完整、准确、全面贯彻新发展理念，以高质量发展为主线，以创新型、市场化、国际化为方向，以产品、制度、技术创新为引领，着力打造绿色、创新型期货交易所，积极服务构建新发展格局，助力实现绿色低碳转型发展
			</p>
			<p><br><img src="https://res.pfmjnru.xyz//storage/article/cover/6f39e7df12297147c0558d26896e2b10.jpeg"
					width="359" height="230"><br></p>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="less">
	.tui-header {
		padding: 0 30rpx;
	}

	.text-des-color {
		font-size: 14px;
		color: #a8a9ac;
		line-height: 24px;
		text-align: justify;
	}
</style>